# @arifsunridge/portal-kit

Shared sign-in, access and activity logging for HBF apps behind the HBF Portal.
Its source lives in `hbf-portal` next to the portal API it talks to, so both
sides of the contract change in one pull request.

## Install in an app (e.g. a twin)

The package is private on GitHub Packages. Add an `.npmrc` to the app repo:

```ini
@arifsunridge:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

Then run `npm install @arifsunridge/portal-kit@<version>`. `NPM_TOKEN` is a GitHub
token with `read:packages`. Set it in your shell locally and as an environment
variable on the Render service.

## Use

See the root `README.md` ("How an app plugs in").

## Release

1. Bump `version` in `packages/portal-kit/package.json`, and merge.
2. Tag the merge commit `portal-kit-v<version>` and push the tag.
3. The `publish-kit` workflow tests, builds and publishes it.
4. Update the apps to the new version.

Keep changes backwards compatible where you can: apps upgrade on their own
schedule.
